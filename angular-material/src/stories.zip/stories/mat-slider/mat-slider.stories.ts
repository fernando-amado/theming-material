import { Story              } from '@storybook/angular/types-6-0';
import { moduleMetadata     } from '@storybook/angular';
import { MatSliderModule    } from '@angular/material/slider';
import { MatSliderComponent } from './mat-slider.component';

export default {
  title: 'Slider',
  component: MatSliderComponent,
  decorators: [
    moduleMetadata({
      imports: [MatSliderModule],
    }),
  ],
  argTypes: {
    color: {
      control: { type: 'radio' },
      options: ['primary', 'accent', 'warn', 'success', 'info', 'warning'],
      description: 'Slider componente usa por defecto el color primary, para hacer uso de los otros colores solo debe cambiar la propiedad `color=" " ` por cualquiera de los siguientes opciones : ',
      defaultValue: 'primary',
    },
  },
  Parameters: {
    backgrounds: {
      values: [{ name: 'dark', value: '#000' }],
    },
  },
};

const Template: Story<MatSliderComponent> = (
  args: MatSliderModule
) => ({
  props: args,
});

export const MatSlider = Template.bind({});
MatSlider.args = {};
