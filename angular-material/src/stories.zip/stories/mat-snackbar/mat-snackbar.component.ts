import { Component, inject, Input } from '@angular/core';
import {MatSnackBar, MatSnackBarRef} from '@angular/material/snack-bar';
@Component({
  selector: 'app-mat-snackbar',
  templateUrl: './mat-snackbar.component.html',
  styleUrls: ['../config-storybook/main.scss']
})
export class MatSnackbarComponent {
  durationInSeconds = 5;

  constructor(private _snackBar: MatSnackBar) {}
  openSnackBar() {
    this._snackBar.openFromComponent(PizzaPartyAnnotatedComponent, {
      duration: this.durationInSeconds * 1000,
    });
  }
@Input () color: 'primary' | 'accent' | 'warn' | 'success' | 'info' | 'warning' = 'primary';
  
public get classes(): string[] {
  return ['app-mat-slidetoggle',`app-mat-slidetoggle--${this.color}`]
}

}
export class PizzaPartyAnnotatedComponent {
  snackBarRef = inject(MatSnackBarRef);
}
