import { Component, Input } from '@angular/core';
@Component({
  selector: 'app-mat-stepper',
  templateUrl: './mat-stepper.component.html',
  styleUrls: ['../config-storybook/main.scss']
})
export class MatStepperComponent {
  constructor() {}

@Input () color: 'primary'|'accent'|'warn'|'success'|'info'|'warning' = 'primary';

public get classes(): string[] {
  return ['app-mat-stepper',`app-mat-stepper--${this.color}`]
}
}
