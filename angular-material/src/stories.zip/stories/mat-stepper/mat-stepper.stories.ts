import { Story                  } from '@storybook/angular/types-6-0';

import { moduleMetadata         } from '@storybook/angular';
import { MatStepperModule       } from '@angular/material/stepper';
import { MatStepperComponent    } from './mat-stepper.component';

export default {
  title: 'Stepper',
  component: MatStepperComponent,
  decorators: [
    moduleMetadata({
      imports: [MatStepperModule],
    }),
  ],
  argTypes: {
    color: {
      control: { type: 'radio' },
      options: ['primary', 'accent', 'warn', 'success', 'info', 'warning'],
      description: 'Stepper componente usa por defecto el color primary, para hacer uso de los otros colores solo debe cambiar la propiedad `color=" " ` por cualquiera de los siguientes opciones : ',
      defaultValue: 'primary',
    },
  },
  Parameters: {
    backgrounds: {
      values: [{ name: 'dark', value: '#000' }],
    },
  },
};

const Template: Story<MatStepperComponent> = (
  args: MatStepperComponent
) => ({
  props: args,
});

export const MatStepper = Template.bind({});
MatStepper.args = {};
