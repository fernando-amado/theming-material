import { Story                   } from '@storybook/angular/types-6-0';
import { moduleMetadata          } from '@storybook/angular';
import { MatSlideToggleModule    } from '@angular/material/slide-toggle';
import { MatSlidetoggleComponent } from 'src/stories/mat-slidetoggle/mat-slidetoggle.component';
export default {
  title: 'Slide toggle',
  component: MatSlidetoggleComponent,
  decorators: [
    moduleMetadata({
      imports: [MatSlideToggleModule],
    }),
  ],
  argTypes: {
    color: {
      control: { type: 'radio' },
      options: ['primary', 'accent', 'warn', 'success', 'info', 'warning'],
      description: 'Slide toggle componente usa por defecto el color primary, para hacer uso de los otros colores solo debe cambiar la propiedad `color=" " ` por cualquiera de los siguientes opciones : ',
      defaultValue: 'primary',
    },
  },
  Parameters: {
    backgrounds: {
      values: [{ name: 'dark', value: '#000' }],
    },
  },
};
const Template: Story<MatSlidetoggleComponent> = (args: MatSlideToggleModule ) => ({ props: args });
export const MatSlideToggle = Template.bind({});
MatSlideToggle.args = {};
