import { Meta, Story            } from '@storybook/angular/types-6-0';
import { MatChipsModule         } from '@angular/material/chips';
import { moduleMetadata         } from '@storybook/angular';
import { MatChipsComponent      } from './mat-chips.component';

export default {
  title: 'Chips',
  component: MatChipsComponent,
  decorators: [
    moduleMetadata({
      imports: [MatChipsModule],
    }),
  ],
  argTypes: {
    color: {
      options: ['primary', 'accent', 'warn', 'success', 'info', 'warning'],
      control: { type: 'radio' },
      description:
        'Chips componente usa por defecto el color primary, para hacer uso de los otros colores solo debe cambiar la propiedad `color=" " ` por cualquiera de los siguientes opciones : ',
    },
  },
  parameters: {
    backgrounds: {
      values: [{ name: 'dark', value: '#000' }],
    },
  },
} as Meta;

const Template: Story<MatChipsComponent> = (
  args: MatChipsComponent
) => ({
  props: args,
});

export const MatChips = Template.bind({});
MatChips.args = {};
