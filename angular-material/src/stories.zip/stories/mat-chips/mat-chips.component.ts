import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-mat-chips',
  templateUrl: './mat-chips.component.html',
  styleUrls: ['../config-storybook/main.scss']

})
export class MatChipsComponent {
  @Input () color?: 'primary'|'accent'|'warn'|'success'|'info'|'warning' = 'primary';
  
  public get classes(): string[] {
    return ['app-mat-chips',`app-mat-chips--${this.color}`]
  }
}
