import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-mat-bagde',
  templateUrl: './mat-bagde.component.html',
  styleUrls: ['../config-storybook/main.scss']
})
export class MatBagdeComponent {
constructor () {}
@Input () color: 'primary' | 'accent' | 'warn' | 'success' | 'info' | 'warning' = 'primary';

public get classes(): string[] {
  return ['app-mat-bagde',`app-mat-bagde--${this.color}`]
}
}
