import { Meta, Story            } from '@storybook/angular/types-6-0';
import { moduleMetadata         } from "@storybook/angular";
import { MatBagdeComponent      } from './mat-bagde.component';
import { MatBadgeModule         } from '@angular/material/badge';
export default {
    title: 'Badge',
    component: MatBagdeComponent ,
    decorators:[
        moduleMetadata({
            imports:[MatBadgeModule]
        })
    ],
    argTypes: {
        color: {
          control: { type: 'radio' }, 
          options: ['primary', 'accent', 'warn','success', 'info', 'warning'],
          description: 'Badge componente usa por defecto el color primary, para hacer uso de los otros colores solo debe cambiar la propiedad `color=" " ` por cualquiera de los siguientes opciones : ',
          defaultValue: 'primary',

        },  
      },
      parameters: {
        backgrounds: {
          values: [
            { name: 'dark', value: '#000' },
          ],
        },

      },
} as Meta

const Template :Story<MatBagdeComponent> = (args: MatBagdeComponent) =>({
    props:args
})

  export const MatBadge = Template.bind({});
  MatBadge.args = {};