import { Component } from '@angular/core';
@Component({
  selector: 'app-mat-bagde',
  templateUrl: './mat-bagde.component.html',
})

export class MatBagdeComponent {}